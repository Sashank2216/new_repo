import { Inject, Injectable, Logger } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { CustomerDetails, KYC } from "../models"; 
import { trace } from "console";
import { Repository } from "typeorm";
import { IKycRepository } from "../interfaces/kyc.repository.interface";

@Injectable()
export class KycRepository implements IKycRepository {
  logger: Logger = new Logger;

  constructor(
    @InjectRepository(KYC)
    private readonly kycRepository: Repository<KYC>
  ) {}

  async getKycDetails(pan: string): Promise<CustomerDetails | null> {
    return this.kycRepository.findOne({ where: { pan } });
  }
}
