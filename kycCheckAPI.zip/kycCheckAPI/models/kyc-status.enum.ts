export enum KYCStatus {
  VERIFIED = "verified",
  NOT_VERIFIED = "not_verified",
  NOT_AVAILABLE = "not_available",
}
