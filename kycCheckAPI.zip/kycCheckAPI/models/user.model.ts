import { KYCStatus } from "./kyc-status.enum";

export interface User {
  pan: string;
  name: string;
  address: string;
  kycStatus: KYCStatus;
}
