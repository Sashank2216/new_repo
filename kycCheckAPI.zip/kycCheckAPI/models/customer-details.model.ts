import { KYCStatus } from "./kyc-status.enum";

export interface CustomerDetails {
  pan: string;
  name: string;
  address: string; 
  kycStatus: KYCStatus;
}
