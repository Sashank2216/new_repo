import { Entity, Column, PrimaryColumn } from "typeorm";
import { KYCStatus } from "./kyc-status.enum";

@Entity()
export class KYC {
  @PrimaryColumn()
  pan!: string;

  @Column()
  name!: string;

  @Column()
  address!: string;

  @Column({
    type: "enum",
    enum: KYCStatus,
  })
  kycStatus!: KYCStatus;
}
