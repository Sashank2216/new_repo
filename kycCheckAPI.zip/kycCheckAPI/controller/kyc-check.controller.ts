import { trace } from "console";
import { Body, Controller, Inject, Logger, Post } from "@nestjs/common";
import { 
  ApiBearerAuth,
  ApiInternalServerErrorResponse,
  ApiOkResponse,
  ApiTags,
  ApiUnauthorizedResponse, 
} from "@nestjs/swagger";
import { KycCheckResponseDTO } from "../dto/kyc-check.response";
import { KycCheckService } from "../services/kyc-check.service";
import { KycValidationPipe } from "../validations/kyc-validation.pipe";

@Controller("kyc-check")
@ApiTags("KycCheck") 
@ApiBearerAuth("JWT-auth")
export class KycCheckController {
  logger: Logger;

  constructor(private readonly kycCheckService: KycCheckService) {
    
  this.logger = new Logger(KycCheckController.name);
  }
  
  @Post()
  @ApiOkResponse({
    description: "KYC Check Successful",
    type: KycCheckResponseDTO,
  })
  @ApiUnauthorizedResponse({ description: "Unauthorized" })
  @ApiInternalServerErrorResponse({ description: "Internal server error" })
  async kycCheck(
    @Body("pan_number", KycValidationPipe) pan_number: string  
  ): Promise<KycCheckResponseDTO> {
    try {
      this.logger.log(this.kycCheck.name);
      const data = await this.kycCheckService.getKycValidatedData(pan_number);
      this.logger.log(`KYC Check Successful for PAN: ${pan_number}`);
      return { data };
    } catch (error: any) { 
      this.logger.error(
        `Error in KYC Check for PAN: ${pan_number}`,
        error,
        trace,
      );
      throw error;
    }
  }
}
