import { trace } from "console";
import { HttpService } from "@nestjs/axios";  
import { Inject, Injectable, Logger } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { AxiosResponse } from "axios"; 
import { firstValueFrom } from "rxjs";
import { User, KYCStatus, CustomerDetails } from "../models";

@Injectable()
export class UserService {
  createProfile(customerDetails: CustomerDetails) {
    throw new Error('Method not implemented.');
  }
  private logger: Logger;

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService
  ) {
    this.logger = new Logger(UserService.name);  
  }
  
  async getUserProfileByUserId(user_id: string): Promise<User> {
    this.logger.log(this.getUserProfileByUserId.name);

    try {
      const query = { user_id };

      const request = this.httpService.post(
        `${this.configService.get("host")}:${this.configService.get("port.user_port")}/user`,
        query, 
      );

      const result = (await firstValueFrom(request)).data as User;
      return result;
    } catch (error: any) {
      this.logger.error(
        `Error in fetching user profile for ID: ${user_id}`,
        error,
        trace,
      );
      throw { message: error.message, status: 500 };  
    }
  }

  // KYC status management
  async updateUserKYCStatus(user_id: string, kyc_status: KYCStatus): Promise<void> {
    this.logger.log(this.updateUserKYCStatus.name);

    try {
      const body = { user_id, kyc_status };

      await firstValueFrom(
        this.httpService.patch(
          `${this.configService.get("host")}:${this.configService.get("port.user_port")}/user/kyc-status`,
          body,
        )
      );
    } catch (error: any) {
      this.logger.error(
        `Error in updating KYC status for user ID: ${user_id}`,
        error, 
        trace,
      );
      throw { message: error.message, status: 500 };
    } 
  }

  // Other user related operations here 
  // User authentication, profile management, notifications, integration with external services, etc.
}  
