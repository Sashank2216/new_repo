import { trace } from "console";
import { HttpService } from "@nestjs/axios";
import { Inject, Injectable, Logger } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { CustomerDetails } from "../models";
import { firstValueFrom } from "rxjs";

  
@Injectable()
export class SchemeService {
  private logger: Logger;

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService
  ) {  
    this.logger = new Logger(SchemeService.name); 
  }

  async getKYCDetailsByPanNumber(pan_number: string): Promise<CustomerDetails> {
    this.logger.log(this.getKYCDetailsByPanNumber.name);

    try { 
      const query = { pan_number };

      const request = this.httpService.post(
        `${this.configService.get("host")}:${this.configService.get("port.kyc_port")}/kyc-details`,
        query,
      );

      const result = (await firstValueFrom(request)).data as CustomerDetails;
      return result;
    } catch (error: any) {
      this.logger.error(
        `Error in fetching KYC details for PAN: ${pan_number}`,
        error,
        trace,
      ); 
      throw { message: error.message, status: 500 };
    }
  }
}
