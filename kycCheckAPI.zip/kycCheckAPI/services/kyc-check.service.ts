import { trace } from "console";
import { Inject, Injectable, Logger } from "@nestjs/common";
import { CustomerDetails, KYCStatus } from "../models";
import { KycRepository } from "../repositories/kyc.repository";  
import { SchemeService } from "./scheme.service";
import { UserService } from "./user.service";
import { KycCheckResponseDTOData } from "../dto/kyc-check.response";

@Injectable()
export class KycCheckService {
  logger: Logger;

  constructor(
    private readonly kycRepository: KycRepository,
    private readonly schemeService: SchemeService,
    private readonly userService: UserService,  
  ) {
    this.logger = new Logger(KycCheckService.name);
  }

  async getKycValidatedData(pan_number: string): Promise<KycCheckResponseDTOData> {
    try {
      this.logger.log(this.getKycValidatedData.name);
      
      const kycDetails = await this.schemeService.getKYCDetailsByPanNumber(pan_number);
      if (!kycDetails) {
        throw new Error(`No KYC details found for PAN: ${pan_number}`);
      }
      
      let kycStatus: KYCStatus;
      let kycRegisterUrl: string | undefined;
      if (kycDetails) {
        kycStatus = kycDetails.kycStatus;
        if (kycStatus === "verified") {
          this.userService.createProfile(kycDetails); 
        } else {
          kycRegisterUrl = this.getKycRegistrationUrl(kycStatus);
        }
      } else {
        throw new Error("PAN not found");
      }
      
      return {
        pan: pan_number,
        kycStatus: kycStatus,
        name: kycDetails.name,
        address: kycDetails.address,
      };
    } catch (error: any) {
      this.logger.error(
        `Error in validating KYC for PAN ${pan_number}`,
        error,
        trace,
      );
      throw { message: error.message, status: 500 }; 
    }
  }
  private getKycRegistrationUrl(kycStatus: KYCStatus): string {
    switch (kycStatus) {
      case KYCStatus.NOT_VERIFIED:
        return 'https://example.com/kyc/not-verified';
      case KYCStatus.NOT_AVAILABLE:
        return 'https://example.com/kyc/not-available';
      default:
        throw new Error(`Invalid KYC status: ${kycStatus}`);
    }
  }
}
