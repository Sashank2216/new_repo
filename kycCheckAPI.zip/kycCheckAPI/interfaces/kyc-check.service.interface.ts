import { KycCheckResponseDTOData } from "../dto/kyc-check.response"; 

export interface IKycCheckService {
  getKycValidatedData(pan_number: string): Promise<KycCheckResponseDTOData>;
}
