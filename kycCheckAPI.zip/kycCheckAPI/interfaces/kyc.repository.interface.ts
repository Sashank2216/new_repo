import { CustomerDetails } from "../models";

export interface IKycRepository {
  getKycDetails(pan_number: string): Promise<CustomerDetails | null>;
}  
