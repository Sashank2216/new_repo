import { HttpModule } from "@nestjs/axios";
import { MiddlewareConsumer, Module, NestModule } from "@nestjs/common";
import {
  AuthModule,
  CustomConfigModule,
  DatabaseModule,
  LoggerMiddleware,
} from "core-lib/dist";
import { KycCheckController } from "./controller/kyc-check.controller";
import { KycRepository } from "./repositories/kyc.repository";
import { KycCheckService } from "./services/kyc-check.service";
import { SchemeService } from "./services/scheme.service"; 
import { UserService } from "./services/user.service";
import { KYC } from "./models";

@Module({
  imports: [
    HttpModule,
    AuthModule,
    CustomConfigModule,
    DatabaseModule,
    DatabaseModule.forFeature([KYC]),
  ],
  controllers: [KycCheckController],
  providers: [KycCheckService, KycRepository, SchemeService, UserService],
})
export class KycCheckModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LoggerMiddleware).forRoutes("*");
  }
}
