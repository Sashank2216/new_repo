import { IsNotEmpty, IsString } from "class-validator";

export class KycCheckRequestDTO {
  @IsNotEmpty()
  @IsString()
  pan_number!: string;
}
