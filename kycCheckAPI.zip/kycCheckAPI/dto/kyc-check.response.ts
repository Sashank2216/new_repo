import { KYCStatus } from "../models";

export class KycCheckResponseDTOData {
  pan: string | undefined;
  kycStatus: KYCStatus | undefined;
  name: string | undefined;
  address: string | undefined;
  kycRegisterUrl?: string;
}

export class KycCheckResponseDTO {
  data: KycCheckResponseDTOData | undefined;
}
