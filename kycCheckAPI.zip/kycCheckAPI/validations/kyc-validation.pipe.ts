import {
  PipeTransform,
  Injectable,
  ArgumentMetadata,
  BadRequestException,
} from "@nestjs/common";
  
@Injectable()
export class KycValidationPipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata) {
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/; 
    if (metadata.type === "query" && metadata.data === "pan") {
      if (!panRegex.test(value)) {
        throw new BadRequestException("Invalid PAN number format");
      }
    }
    return value;
  }
}
